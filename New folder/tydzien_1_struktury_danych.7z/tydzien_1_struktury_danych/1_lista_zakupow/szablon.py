"""
ZADANIE 1.1: Lista zakupów
==========================

Program do zarządzania listą zakupów z interaktywnym menu.

Przeczytaj plik 'zadanie.md' aby poznać szczegóły.
"""


def wyswietl_menu():
    """Wyświetla menu opcji"""
    print("\n" + "="*30)
    print("=== LISTA ZAKUPÓW ===")
    print("="*30)
    # TODO: Wyświetl opcje 1-5
    # 1. Dodaj produkt
    # 2. Usuń produkt
    # 3. Wyświetl listę
    # 4. Posortuj alfabetycznie
    # 5. Wyjście



def dodaj_produkt(zakupy):
    """Dodaje produkt do listy zakupów"""
    # TODO: Zapytaj użytkownika o nazwę produktu


    # TODO: Dodaj produkt do listy


    # TODO: Wyświetl komunikat: "Dodano produkt: {nazwa}"



def usun_produkt(zakupy):
    """Usuwa produkt z listy zakupów"""
    # TODO: Sprawdź czy lista jest pusta
    # Jeśli tak, wyświetl "Lista jest pusta!" i zakończ funkcję (return)


    # TODO: Zapytaj użytkownika o nazwę produktu do usunięcia


    # TODO: Sprawdź czy produkt istnieje w liście
    # Wskazówka: if produkt in zakupy:


        # TODO: Usuń produkt z listy


        # TODO: Wyświetl "Usunięto produkt: {nazwa}"


    # TODO: Obsłuż przypadek gdy produktu nie ma (else)
    # Wyświetl "Produkt nie znaleziony!"



def wyswietl_liste(zakupy):
    """Wyświetla wszystkie produkty z listy"""
    # TODO: Sprawdź czy lista jest pusta
    # Jeśli tak, wyświetl "Lista jest pusta!" i zakończ (return)


    # TODO: Wyświetl nagłówek "Twoja lista zakupów:"


    # TODO: Wyświetl produkty z numerami
    # Wskazówka: użyj enumerate(zakupy, start=1)



def sortuj_liste(zakupy):
    """Sortuje listę alfabetycznie"""
    # TODO: Posortuj listę
    # Wskazówka: zakupy.sort()


    # TODO: Wyświetl "Lista została posortowana!"



def main():
    """Główna funkcja programu"""

    # TODO: Stwórz pustą listę zakupów


    # TODO: Stwórz pętlę nieskończoną (while True)


        # TODO: Wyświetl menu
        # Wskazówka: wywołaj funkcję wyswietl_menu()


        # TODO: Pobierz wybór użytkownika


        # TODO: Obsłuż wybór opcji (if/elif/else)
        # Opcja "1" -> wywołaj dodaj_produkt(zakupy)
        # Opcja "2" -> wywołaj usun_produkt(zakupy)
        # Opcja "3" -> wywołaj wyswietl_liste(zakupy)
        # Opcja "4" -> wywołaj sortuj_liste(zakupy)
        # Opcja "5" -> wyświetl "Do widzenia!" i zakończ (break)
        # Inne -> wyświetl "Nieprawidłowy wybór!"




if __name__ == "__main__":
    main()
