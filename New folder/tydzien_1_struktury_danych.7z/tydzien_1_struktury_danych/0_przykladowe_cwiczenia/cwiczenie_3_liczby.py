"""
ĆWICZENIE 3: Kalkulator liczb
==============================

POZIOM: TRUDNIEJSZE
CZAS: 15-20 minut

CEL:
Nauczyć się:
- Pętli nieskończonej (while True)
- Konwersji typów (float)
- Funkcji matematycznych: sum(), min(), max()
- Obliczania średniej

ZADANIE:
Program w pętli zbiera liczby od użytkownika.
Gdy użytkownik wpisze 0, program kończy zbieranie i wyświetla statystyki:
- Suma wszystkich liczb
- Średnia arytmetyczna
- Najmniejsza liczba
- Największa liczba
"""


def main():
    """Główna funkcja programu"""

    print("=== KALKULATOR LICZB ===")
    print("Podawaj liczby (wpisz 0 aby zakończyć)\n")

    # TODO: Stwórz pustą listę 'liczby'


    # TODO: Stwórz nieskończoną pętlę
    # Wskazówka: while True:


        # TODO: Zapytaj użytkownika o liczbę i zamień ją na float
        # Wskazówka: liczba = float(input("Podaj liczbę: "))


        # TODO: Sprawdź czy liczba == 0
        # Jeśli tak, przerwij pętlę (break)


        # TODO: Dodaj liczbę do listy



    # Sprawdzenie czy lista nie jest pusta
    if len(liczby) == 0:
        print("Nie podałeś żadnych liczb!")
        return

    # TODO: Wyświetl separator
    print("\n" + "="*40)
    print("STATYSTYKI:")
    print("="*40)

    # TODO: Oblicz i wyświetl sumę wszystkich liczb
    # Wskazówka: suma = sum(liczby)


    # TODO: Oblicz i wyświetl średnią
    # Wskazówka: srednia = sum(liczby) / len(liczby)


    # TODO: Znajdź i wyświetl najmniejszą liczbę
    # Wskazówka: min(liczby)


    # TODO: Znajdź i wyświetl największą liczbę
    # Wskazówka: max(liczby)


    # BONUS:
    # TODO: Wyświetl ile liczb zostało podanych
    # Wskazówka: len(liczby)



if __name__ == "__main__":
    main()
