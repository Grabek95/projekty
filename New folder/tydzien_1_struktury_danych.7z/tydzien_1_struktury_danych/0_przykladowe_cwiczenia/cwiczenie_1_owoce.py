"""
ĆWICZENIE 1: Lista owoców
=========================

POZIOM: ŁATWE
CZAS: 5-10 minut

CEL:
Nauczyć się podstaw pracy z listami:
- Tworzenie pustej listy
- Dodawanie elementów metodą append()
- Wyświetlanie zawartości listy

ZADANIE:
Zapytaj użytkownika o 3 owoce, dodaj je do listy i wyświetl całą listę.
"""


def main():
    """Główna funkcja programu"""

    print("=== LISTA OWOCÓW ===\n")

    # TODO: Stwórz pustą listę o nazwie 'owoce'


    # TODO: Zapytaj użytkownika o pierwszy owoc i dodaj go do listy
    # Wskazówka: użyj input() i append()


    # TODO: Zapytaj użytkownika o drugi owoc i dodaj go do listy


    # TODO: Zapytaj użytkownika o trzeci owoc i dodaj go do listy


    # TODO: Wyświetl komunikat "Twoja lista owoców:"


    # TODO: Wyświetl całą listę
    # Wskazówka: po prostu print(owoce)


    # BONUS (opcjonalnie):
    # TODO: Wyświetl każdy owoc w osobnej linii z numerem
    # Wskazówka: użyj pętli for z enumerate()
    # Przykład: for index, owoc in enumerate(owoce, start=1):



if __name__ == "__main__":
    main()
