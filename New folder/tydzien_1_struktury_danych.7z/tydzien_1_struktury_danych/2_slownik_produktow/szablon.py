"""
ZADANIE 1.2: Słownik produktów
===============================

Program do zarządzania produktami (nazwa → cena) używając słownika.

Przeczytaj plik 'zadanie.md' aby poznać szczegóły.
"""


def wyswietl_menu():
    """Wyświetla menu opcji"""
    print("\n" + "="*30)
    print("=== SŁOWNIK PRODUKTÓW ===")
    print("="*30)
    # TODO: Wyświetl opcje 1-6



def dodaj_produkt(produkty):
    """Dodaje produkt do słownika"""
    # TODO: Zapytaj o nazwę produktu


    # TODO: Zapytaj o cenę produktu i zamień na float
    # Wskazówka: cena = float(input(...))


    # TODO: Dodaj produkt do słownika
    # Wskazówka: produkty[nazwa] = cena


    # TODO: Wyświetl komunikat z formatowaniem ceny (.2f)



def usun_produkt(produkty):
    """Usuwa produkt ze słownika"""
    # TODO: Sprawdź czy słownik jest pusty


    # TODO: Zapytaj o nazwę produktu do usunięcia


    # TODO: Sprawdź czy produkt istnieje w słowniku
    # Wskazówka: if nazwa in produkty:


        # TODO: Usuń produkt
        # Wskazówka: del produkty[nazwa]


        # TODO: Wyświetl komunikat


    # TODO: Obsłuż przypadek gdy produktu nie ma (else)



def wyswietl_produkty(produkty):
    """Wyświetla wszystkie produkty"""
    # TODO: Sprawdź czy słownik jest pusty


    # TODO: Wyświetl nagłówek


    # TODO: Iteruj po słowniku i wyświetl każdy produkt
    # Wskazówka: for nazwa, cena in produkty.items():
    # Format: - Mleko: 3.50 PLN



def znajdz_najtanszy(produkty):
    """Znajduje i wyświetla najtańszy produkt"""
    # TODO: Sprawdź czy słownik jest pusty


    # TODO: Znajdź nazwę produktu z minimalną ceną
    # Wskazówka: najtanszy = min(produkty, key=produkty.get)


    # TODO: Pobierz cenę tego produktu
    # Wskazówka: cena = produkty[najtanszy]


    # TODO: Wyświetl wynik z formatowaniem



def znajdz_najdrozszy(produkty):
    """Znajduje i wyświetla najdroższy produkt"""
    # TODO: Sprawdź czy słownik jest pusty


    # TODO: Znajdź nazwę produktu z maksymalną ceną
    # Wskazówka: najdrozszy = max(produkty, key=produkty.get)


    # TODO: Pobierz cenę tego produktu


    # TODO: Wyświetl wynik z formatowaniem



def main():
    """Główna funkcja programu"""

    # TODO: Stwórz pusty słownik produktów


    # TODO: Pętla nieskończona


        # TODO: Wyświetl menu


        # TODO: Pobierz wybór użytkownika


        # TODO: Obsłuż wybór (if/elif/else)
        # 1 -> dodaj_produkt(produkty)
        # 2 -> usun_produkt(produkty)
        # 3 -> wyswietl_produkty(produkty)
        # 4 -> znajdz_najtanszy(produkty)
        # 5 -> znajdz_najdrozszy(produkty)
        # 6 -> wyświetl "Do widzenia!" i break
        # inne -> "Nieprawidłowy wybór!"




if __name__ == "__main__":
    main()
